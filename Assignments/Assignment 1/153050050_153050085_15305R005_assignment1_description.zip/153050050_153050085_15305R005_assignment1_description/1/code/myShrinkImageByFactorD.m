%% myShrinkImageByFactorD

function [out] = myShrinkImageByFactorD(in, D)

[row, col] = size(in);

out = in(1:D:row, 1:D:col);

end


% out = zeros(row,col);

% prompt = 'Enter the D value(subsampling)? ';
%k=1, l=1;
%for i=1:D:row
%	for j=1:D:col
%		out(k,l) = in(i,j);
%		l=l+1;
%	end
%	k=k+1, l=1;
%end

% image(out) 
% axis image
% subplot(2,2,3), imshow(in), colorbar('southoutside')
% subplot(2,2,4), imshow(out), colorbar('southoutside')

